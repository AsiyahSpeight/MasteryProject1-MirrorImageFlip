Sample README.txt file for CPSC-230 at Chapman University 

AUTHOR INFO
Full name: Elia Eiroa Lledo 
Student ID: 123456
Chapman Email: eiroalledo@chapman.edu 
Course number and section: CPSC-230-03
Assignment or exercise number: PA 1: Baker's Calculator 

ERRORS 
A description of any known compile or runtime errors, code limitations, or deviations
from the assignment specification (if applicable)
E.g. the flour is not calculated accurately 

SOURCES
A list of all references used to complete the assignment, including peers (if applicable)
I worked alongside my roommate Benito Martínez Ocasio
I also used the following links as reference (also listed in the code file):
    - https://www.w3schools.com/python/gloss_python_if_statement.asp
    - other specific links 

